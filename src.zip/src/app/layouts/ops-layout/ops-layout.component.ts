import { Component, OnInit } from '@angular/core';
import { ThemeService } from '../../core/services';
import { NgxSmartModalService } from 'ngx-smart-modal';
import { DataTrasferService } from 'app/shared/services';
import { AuthService } from '../../core/services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-ops-layout',
  templateUrl: './ops-layout.component.html',
  styleUrls: ['./ops-layout.component.scss']
})
export class OpsLayoutComponent implements OnInit {
  userName: string;
  constructor(
    private overallColor: ThemeService,
    public modalService: NgxSmartModalService,
    private serviceDataTransfer: DataTrasferService,
    private auth: AuthService,
    private router: Router
    ) {
    this.overallColor.toggleLight('#003f88');
    this.userName = sessionStorage.getItem("user")

    this.serviceDataTransfer.currentData.subscribe(res => {
      if (res == 'ok') {
        this.auth.logout();
        this.router.navigate(['/auth/login']);
        this.openPopUp({
          title: 'Success!',
          msg: 'You have been logged out successfully'
        });
      }
      else {
        this.modalService.getModal('infoModal').close();
      }
    });
   }

  ngOnInit() {
  }

  logOut() {
    this.openPopUp({
      title: 'Confirmation',
      msg: 'Are you sure want to logout ?',
      confirmation: 'need',
      purpose: 'LogOut'
    });
  }

  openPopUp(obj) {
    this.modalService.setModalData(obj, 'infoModal', true);
    this.modalService.getModal('infoModal').open()
  }

}
