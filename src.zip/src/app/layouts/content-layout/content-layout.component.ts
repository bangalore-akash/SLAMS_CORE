import { Component, OnInit } from '@angular/core'; 
import {Router} from '@angular/router';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';


@Component({
  selector: 'app-content-layout',
  templateUrl: './content-layout.component.html',
  styleUrls: ['./content-layout.component.scss']
})
export class ContentLayoutComponent implements OnInit {
  private activeURL : string
  cholaicon = '/assets/images/CholaIcon.png';
  constructor(
    private router: Router
      ) { 

    this.router.events.subscribe((res) => { 
      this.activeURL = this.router.url
  })

  
    // const url: Observable<string> = route.url.pipe(map(segments => segments.join('')));

   
  }

  ngOnInit() {
    
  } 

}
