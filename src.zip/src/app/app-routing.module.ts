import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
// import { HeaderComponent, NavComponent, FnfComponent } from 'src/app/shared/index';
// import { moduleRoutes } from 'src/app/shared/index';
// import { AuthGuard } from 'src/app/core/index';
import { NoAuthGuard, AuthGuard } from '@app/core';

import { AuthLayoutComponent } from './layouts/auth-layout/auth-layout.component';
import { ContentLayoutComponent } from './layouts/content-layout/content-layout.component';
 

const routes: Routes = [
  {
    path: '',
    redirectTo: 'auth/login',
    pathMatch: 'full'
  },
  // { 
  //   path: 'auth',   
  //   component: HeaderComponent,
  //   children: moduleRoutes
  // },
  {
    path: 'auth',
    component: AuthLayoutComponent,
    loadChildren: 'app/modules/auth/auth.module#AuthModule'
  },
  {
    path: 'cpu',
    component: ContentLayoutComponent, 
    canActivate: [AuthGuard],
    data: {
      roles: ["CPU Ops User"]
    },
    loadChildren: 'app/modules/cpu/cpu.module#CpuModule'
  },
  // {
  //   path: 'user',
  //   component: NavComponent,
  //   canActivate: [AuthGuard],
  //   children: moduleRoutes
  // },
  // {
  //   path: 'pageNotFound',
  //   component: FnfComponent
  // },
  {
    path: '**',
    redirectTo: 'pageNotFound',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
