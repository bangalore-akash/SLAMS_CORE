import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from '@app/app-routing.module';
import { AppComponent } from '@app/app.component';
// import { HeaderComponent, FooterComponent, NavComponent, FnfComponent } from 'src/app/shared/index';
// import { SharedModule } from 'src/app/shared/shared.module';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
// import { AuthGuard } from 'src/app/core/index';
import { HttpClientModule } from '@angular/common/http';

import { CoreModule } from '@app/core';
import { SharedModule } from '@app/shared';
import { NoAuthGuard, AuthGuard } from '@app/core';
import { AuthLayoutComponent } from './layouts/auth-layout/auth-layout.component';

import { ContentLayoutComponent } from './layouts/content-layout/content-layout.component';
import { NavComponent } from './layouts/nav/nav.component';
import { FooterComponent } from './layouts/footer/footer.component';
import { AuthModule } from './modules/auth/auth.module';
import { NgxSmartModalModule } from 'ngx-smart-modal';

@NgModule({
  declarations: [
    AppComponent, 
    AuthLayoutComponent,
    ContentLayoutComponent,
    NavComponent,
    FooterComponent
    // HeaderComponent,
    // FooterComponent,NavComponent, FnfComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    AuthModule,
    CoreModule,
    SharedModule,
    HttpClientModule,
    NgxSmartModalModule.forRoot()
  ],
  providers: [{provide: LocationStrategy, useClass: HashLocationStrategy},AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
