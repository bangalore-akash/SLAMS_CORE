import { Injectable } from '@angular/core';
import { ApiService } from '@app/core';
import { environment as env } from '@env/environment';

const BASE_URL = env.serverUrlSet.users;

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor( private apiservices: ApiService ) { }

  getEntitlemets(){
      const targetUrl= `${BASE_URL}/employees/entitlements`
      return this.apiservices.get(targetUrl);
  }

}
