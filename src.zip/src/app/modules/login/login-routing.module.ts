import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './pages/login/login.component';
// import { ForgetPasswordComponent } from './pages/forget-password/forget-password.component';


const routes: Routes = [
  {
    path: '',
    component: LoginComponent
  },
  // {
  //   path: 'forgetPassword',
  //   component: ForgetPasswordComponent
  // },
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full'
  },
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class LoginRoutingModule { }
