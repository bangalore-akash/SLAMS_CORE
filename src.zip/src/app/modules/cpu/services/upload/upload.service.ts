import { Injectable } from '@angular/core';
import { ApiService } from '@app/core';
import { environment as env } from '@env/environment';
import { HttpHeaders } from '@angular/common/http';
import { getCustomHeaders } from '@app/core/services/api-utils';

const BASE_URL = env.serverUrlSet.users;

@Injectable({
  providedIn: 'root'
})
export class UploadService {

  constructor(private apiservices: ApiService) { }

  uploadInventory(data){
    let additionalHeaderParams = {
      user_id: 105,
      selectedRoleID: 'ROL201',
    };
    const targetUrl= `/stampingapi/laInventory/updateLAInventory`;
    return this.apiservices.post(targetUrl, data, getCustomHeaders(additionalHeaderParams));
}

  allInventoryDetails(){
    const targetUrl = `/stampingapi/laInventory/getLAinventoryDetails?state=all`;
    return this.apiservices.get(targetUrl)
  }
  
}
