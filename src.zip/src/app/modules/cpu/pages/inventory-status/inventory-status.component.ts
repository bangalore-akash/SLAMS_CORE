import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inventory-status',
  templateUrl: './inventory-status.component.html',
  styleUrls: ['./inventory-status.component.css']
})
export class InventoryStatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
