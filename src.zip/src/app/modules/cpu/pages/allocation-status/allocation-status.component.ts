import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-allocation-status',
  templateUrl: './allocation-status.component.html',
  styleUrls: ['./allocation-status.component.css']
})
export class AllocationStatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
