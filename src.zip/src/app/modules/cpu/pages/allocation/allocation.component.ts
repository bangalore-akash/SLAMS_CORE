import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { AllocationService } from '../../services/allocation/allocation.service';
import { NgxSpinnerService } from "ngx-spinner";
import Swal from 'sweetalert2/dist/sweetalert2.js';

@Component({
  selector: 'app-allocation',
  templateUrl: './allocation.component.html',
  styleUrls: ['./allocation.component.css']
})
export class AllocationComponent implements OnInit {

  allocateAgrForm : FormGroup;
  submitted: boolean = false;
  error: any;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private allocationService:AllocationService,
    private spinner: NgxSpinnerService
    ) {
      this.allocateAgrForm = this.formBuilder.group({
        state: ["", Validators.required ],
        serialFrom: ["", Validators.required ],
        serialTo: ["", Validators.required ],
        count: ["", Validators.required ],
      })
    }

    get f() {
      return this.allocateAgrForm.controls;
    }

  ngOnInit() {
  }

  viewAll() {
    this.router.navigate(['/user/cpu/allocationStatus']);
  }

  alocateToNextUser(){
    this.submitted = true;
    if (this.allocateAgrForm.invalid) {
     return;
   }
   var Formelement = this.allocateAgrForm.value;
    this.spinner.show();

    this.allocationService.allocateAgreements('').pipe(
      tap(response =>{
        console.log(response);
        Swal.fire('success', response, 'success')
       }),
       finalize(() => this.spinner.hide()),
       catchError(error => of(
        Swal.fire('Oops...', error.errors[0].message, 'error'),
        ))
    ).subscribe()
  }

}
