import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { UploadService } from '../../services/upload/upload.service';
import { NgxSpinnerService } from "ngx-spinner";
import Swal from 'sweetalert2/dist/sweetalert2.js';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnInit {
  
  uploadLoanAgrForm : FormGroup;
  submitted: boolean = false;
  error: any;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private uploadService: UploadService,
    private spinner: NgxSpinnerService
    ) {
      this.uploadLoanAgrForm = this.formBuilder.group({
        state: ["", Validators.required ],
        serialFrom: ["", Validators.required ],
        serialTo: ["", Validators.required ],
        count: ["", Validators.required ],
      })
    }

    get f() {
      return this.uploadLoanAgrForm.controls;
    }

    uploadLoanAgr() {
      this.submitted = true;
      if (this.uploadLoanAgrForm.invalid) {
       return;
     }
     var Formelement = this.uploadLoanAgrForm.value;
      Formelement["channel"] = 'web';
      this.spinner.show();
      this.uploadService.uploadInventory(Formelement).pipe(
      tap(response =>{
       console.log(response);
       Swal.fire('success', response, 'success')
      }),
      finalize(() => this.spinner.hide()),
      catchError(error => of(
        // Swal.fire('Oops...', error.errors[0].message, 'error'),
        Swal.fire('Oops...', 'Something went wrong!', 'error')
        ))
    ).subscribe();
    }

    getAllInventory(){
      this.spinner.show();
      this.uploadService.allInventoryDetails().pipe(
        tap(response =>{
         console.log(response);
         Swal.fire({
          title: 'success!',
          text: 'Successfully Inserted',
          icon: 'success',
          confirmButtonText: 'Cool'
        })
         
       }),
      finalize(() => this.spinner.hide()),
      catchError(error => of(this.error = error))
      ).subscribe()
    }

  row = [
    {
      state: '',
      serialFrom: '',
      serialTo: '',
      count: ''
    }
  ]
  rowCount: number;

  ngOnInit() {
    this.getAllInventory()
  }

  

  addRow(){
    const obj = {
      state: '',
      serialFrom: '',
      serialTo: '',
      count: ''
    }
    this.row.push(obj);
    this.rowCount = this.row.length;
    
  }

  delRow(index){
    this.row.splice(index, 1);
    this.rowCount = this.row.length;
  }

  viewAll(){
    this.router.navigate(['cpu/inventoryStatus']);
  }

}
