import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { CommonModule } from '@angular/common';
import { UploadComponent } from './pages/upload/upload.component';
import { InventoryStatusComponent } from './pages/inventory-status/inventory-status.component';
import { AllocationComponent } from './pages/allocation/allocation.component';
import { AllocationStatusComponent } from './pages/allocation-status/allocation-status.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: '/cpu/dashboard',
    pathMatch: 'full'  },
  
  {
    path: 'dashboard',
    component: DashboardComponent
  },
  {
    path: 'upload',
    component: UploadComponent
  },
  {
    path: 'inventoryStatus',
    component: InventoryStatusComponent
  },
  {
    path: 'allocation',
    component: AllocationComponent
  },
  {
    path: 'allocationStatus',
    component: AllocationStatusComponent
  },
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full'
  },
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class CpuRoutingModule { }
