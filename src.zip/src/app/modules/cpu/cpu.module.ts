import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CpuRoutingModule } from './cpu-routing.module';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { UploadComponent } from './pages/upload/upload.component';
import { InventoryStatusComponent } from './pages/inventory-status/inventory-status.component';
import { AllocationComponent } from './pages/allocation/allocation.component';
import { AllocationStatusComponent } from './pages/allocation-status/allocation-status.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { SharedModule } from '@app/shared/shared.module';

@NgModule({
  declarations: [DashboardComponent, UploadComponent, InventoryStatusComponent, AllocationComponent, AllocationStatusComponent],
  imports: [
    CommonModule,
    CpuRoutingModule,
    SharedModule,
    ReactiveFormsModule,
    FormsModule
  ]
})
export class CpuModule { }
