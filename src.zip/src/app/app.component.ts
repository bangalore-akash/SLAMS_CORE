import { Component } from '@angular/core';
import { NgxSmartModalService, NgxSmartModalComponent } from 'ngx-smart-modal'
import { ModalInstance } from 'ngx-smart-modal/src/services/modal-instance';
import { DataTrasferService } from 'app/shared/services';
import { ApiService } from '@app/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'InventorySystem';
  // title = 'Co Lendng | Master | Home';
  getModal = true
  mtitle = 'Internal Server Error'
  mMsg = 'Unknown Error, Please contact Admin Team'
  mBtn = 'Ok';
  confirm: any;
  needFor: any;
  imgLink: any;
  image: any;
  OPSdetailedView: any;
  role: any;
  selectedRole = 'defaultRole';
  changeWidthModal: any;
  utrNumber: '';
  OPSCollectiondetailedView: any;
  preEmiErrMsg = false;

  constructor(
    public modalService: NgxSmartModalService,
    public serviceDataTransfer: DataTrasferService,
    // private apiService: ApiService,
    // private sanitizer: DomSanitizer,
    private route: Router
  ) {}

  
  ngAfterViewInit() {
    var self = this
    this.modalService.getModal('infoModal').onDataAdded.subscribe((modal: NgxSmartModalComponent) => {
      if(modal['msg'] == "Invalid Token. Please login again"){
        this.route.navigate(['/auth/login']);
      }
      this.role = modal['roles'];
      if(this.role){
        this.selectedRole = 'defaultRole';
      }
      self.mtitle = modal['title'] ? modal['title'] : self.mtitle;
      self.mMsg = modal['msg'] ? modal['msg'] : self.mMsg;
      self.confirm = modal['confirmation'];
      self.needFor = modal['purpose'];
      self.imgLink = modal['imageUrl'];
      this.image = '';
      // if (modal['imageUrl']) {
      //   this.getImg(modal['imageUrl']);
      //   this.confirm = 'No need';
      // }
    }); 
   
  }

  getRoleInformation(val){   
    this.serviceDataTransfer.getRole(val);
  }


}
