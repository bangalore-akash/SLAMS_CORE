import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment as env } from '@env/environment';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

const BASE_URL = env.serverUrlSet;

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private options = { headers: new HttpHeaders().set('Content-Type', 'application/json') };

  constructor(
    private httpClient: HttpClient,
  ) { }

  public get(path: string): Observable<any> {
      return this.httpClient.get(path).pipe(catchError(this.formatErrors));
  }

  public post(path: string, body: object = {}, headers?: object): Observable<any> {
      return this.httpClient.post(path, body, headers !== undefined ? headers: null).pipe(catchError(this.formatErrors));
  }

  public put(path: string, app: string, body: object = {}): Observable<any> {
    return this.httpClient
      .put( path, JSON.stringify(body), this.options)
      .pipe(catchError(this.formatErrors));
  }


  public delete(path: string): Observable<any> {
    return this.httpClient.delete(BASE_URL + path).pipe(catchError(this.formatErrors));
  }

  public loginpost(path: string, app: string, body: object = {}): Observable<Response> {
    if (path === '/auth/authenticate') {
      this.options['observe'] = 'response';
    } 
    if (app == 'repayment') {
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        }),
        observe: 'response' as 'body'
      };
      return this.httpClient
        .post(BASE_URL[app], JSON.stringify(body), httpOptions)
        .pipe(catchError(this.formatErrors));
    }
    else {
      return this.httpClient
        .post(BASE_URL[app] + path, body, this.options)
        .pipe(catchError(this.formatErrors));
    }
  }

  public formatErrors(error: any): Observable<any> {
    return throwError(error.error);
  }
}
