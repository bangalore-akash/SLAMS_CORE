import { HttpHeaders } from '@angular/common/http'

export function  getCustomHeaders (headerParams?: any ): {headers: HttpHeaders}{
  let customHeaders = new HttpHeaders().set('Content-Type', 'application/json');
if(headerParams){    
for(let [key, paramVal] of Object.entries(headerParams)){
    customHeaders= customHeaders.set(key, ""+paramVal);
}
}
return {headers : customHeaders};
}