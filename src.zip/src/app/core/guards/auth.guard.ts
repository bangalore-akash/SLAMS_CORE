import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { Observable } from 'rxjs';

@Injectable()
export class AuthGuard implements CanActivate {

    constructor(
        private authService: AuthService,
        private router: Router
    ) { }

    canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
        let token = this.authService.getToken();
        let role = this.authService.getRole();
        console.log(role);
        
        if (token && next.data.roles && !next.data.roles.includes(role)) {
            this.authService.logout();
            this.router.navigate(['/auth/login']);
            return false;
        }else if(token) {
            return true;
        }
    }

}
