import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ApiService, AuthService } from '@app/core';
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
// import { getHeaders } from '@app/core/services/api-utils';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnInit {
  
  uploadLoanAgrForm : FormGroup;
  submitted: boolean = false;
  error: any;
  isLoading: boolean;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private apiService: ApiService,
    // private auth: AuthService
    ) {
      this.uploadLoanAgrForm = this.formBuilder.group({
        state: ["", Validators.required ],
        serialFrom: ["", Validators.required ],
        serialTo: ["", Validators.required ],
        count: ["", Validators.required ],
      })
    }

    get f() {
      return this.uploadLoanAgrForm.controls;
    }

    uploadLoanAgr() {
      this.submitted = true;
      if (this.uploadLoanAgrForm.invalid) {
       return;
     }
     
     var Formelement = this.uploadLoanAgrForm.value;
     Formelement["channel"] = 'web';
     console.log(Formelement);
     let additionalHeaderParams = {
      user_id: 105,
      selectedRoleID: 'ROL201',
    };

    
     this.apiService.post('/stampingapi/laInventory/updateLAInventory', '', Formelement,additionalHeaderParams).pipe(
      tap(response =>{
       console.log(response);
       
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe();
    }

  row = [
    {
      state: '',
      serialFrom: '',
      serialTo: '',
      count: ''
    }
  ]
  rowCount: number;

  ngOnInit() {
      this.apiService.get('/stampingapi/laInventory/getLAinventoryDetails?All','',{}).pipe(
        tap(response =>{
          console.log(response);
          
        }),
        finalize(() => this.isLoading = false),
        catchError(error => of(this.error = error))
      ).subscribe()
  }

  addRow(){
    const obj = {
      state: '',
      serialFrom: '',
      serialTo: '',
      count: ''
    }
    this.row.push(obj);
    this.rowCount = this.row.length;
    
  }

  delRow(index){
    this.row.splice(index, 1);
    this.rowCount = this.row.length;
  }

  viewAll(){
    this.router.navigate(['cpu/inventoryStatus']);
  }

}
