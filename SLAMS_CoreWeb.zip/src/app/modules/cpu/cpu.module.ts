import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CpuRoutingModule } from './cpu-routing.module';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
// import { SharedModule } from 'src/app/shared/shared.module';
import { UploadComponent } from './pages/upload/upload.component';
import { InventoryStatusComponent } from './pages/inventory-status/inventory-status.component';
import { AllocationComponent } from './pages/allocation/allocation.component';
import { AllocationStatusComponent } from './pages/allocation-status/allocation-status.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

@NgModule({
  declarations: [DashboardComponent, UploadComponent, InventoryStatusComponent, AllocationComponent, AllocationStatusComponent],
  imports: [
    CommonModule,
    CpuRoutingModule,
    // SharedModule,
    ReactiveFormsModule,
    FormsModule
  ]
})
export class CpuModule { }
