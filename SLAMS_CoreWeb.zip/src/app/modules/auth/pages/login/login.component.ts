import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { tap, map, finalize, catchError, } from 'rxjs/operators';
import { of, throwError, from } from 'rxjs';
import { AuthService, ApiService } from '@app/core';
import { NgxSmartModalService } from 'ngx-smart-modal';
import { DataTrasferService } from 'app/shared/services';
import { ITS_JUST_ANGULAR } from '@angular/core/src/r3_symbols';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  error: string;
  isLoading: boolean = false;
  loginForm: FormGroup;
  userId: FormControl;
  Password: FormControl;
  showLogin: boolean;
  errorMsg: string;
  lockClass: any;
  lockStyle: any;
  roles: any;
  selectedRole: any;

  fullImagePath:string;
  passwordtype: string;
  

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private authService: AuthService,
    private apiService: ApiService,
    public modalService: NgxSmartModalService,
    private serviceDataTransfer: DataTrasferService
  ) {
    this.fullImagePath = '/assets/images/inventory1.png';

    this.createFormControler();
    this.createForm();
    this.lockClass = 'fa-lock';
    this.lockStyle = {
      'color': 'rgba(0, 63, 136, 0.81)'
    }
  }

  showpassword() {
    if (this.passwordtype === 'password') {
      this.passwordtype = 'text';
    } else {
      this.passwordtype = 'password';
    }
  }

  gotoForgotPass(){
    this.router.navigate(['/auth/login/forgetPassword']);
  }


  createFormControler() {
    this.userId = new FormControl('SF00247', Validators.required);
    this.Password = new FormControl('leap@1234', Validators.required);
  }

  createForm() {
    this.loginForm = new FormGroup({
      userId: this.userId,
      Password: this.Password

    })
  }

  ngOnInit() {
    // if (this.authService.getToken()) {
    //   this.router.navigate(['/dashboard'])
    // } else {
    //   this.showLogin = true
    // }
  }

  login() {
    this.isLoading = true;
    let self = this
    const credentials = this.loginForm.value;
    console.log(credentials);
    
    if (self.loginForm.valid) {
      this.authService.login(credentials)
        .pipe(
          map(users => {
            if (users.body && users.body.status === "success") {
              sessionStorage.setItem('token', users.headers.get('leapauthtoken'));
              this.lockClass = 'fa-unlock-alt';
              this.lockStyle = {
                'color': '#00a85a'
              }
              this.apiService.get('/employees/entitlements', 'users', {}).pipe(
                tap(entitlements => {
                  if (entitlements && entitlements[0]) {
                    setTimeout(() => {
                      this.roles = [];
                      entitlements[0].roles.map((roleValues: any) => {
                        if (roleValues.roleID == "ROL201" || roleValues.roleID == "ROL202" || roleValues.roleID == "ROL203" || roleValues.roleID == "ROL204"){
                          this.roles.push(roleValues);
                        }
                      });
                      if(this.roles.length > 1){
                        this.openPopUp({
                          title: 'Select Role',
                          roles: this.roles
                        });
                      }
                      else if(this.roles.length == 1){
                        const singleNav = this.roles[0].roleName;
                        sessionStorage.setItem('role', singleNav);
                        if(singleNav == 'COLEN_UNDERWRITING'){
                          this.router.navigate(['/dashboard']);
                        }
                        else{
                          this.router.navigate([singleNav]);
                        }
                      }
                      else{
                        this.openPopUp({
                              title: 'Access Denied',
                              msg: 'You may not have the appropriate permissions to access the application.'
                            })
                      }
                      
                      
                      sessionStorage.setItem('user', entitlements[0].userName);
                      sessionStorage.setItem('color', entitlements[0].theme);
                      sessionStorage.setItem('themeBasedImage', entitlements[0].theme);
                      this.serviceDataTransfer.currentRole.subscribe(res => {
                        this.selectedRole = res;
                        sessionStorage.setItem('role', this.selectedRole);
                        // if (this.selectedRole == 'COLEN_UNDERWRITING') {
                          this.router.navigate(['/cpu']);
                        // }
                        // else {
                          // this.router.navigate([this.selectedRole]);
                        // }
                      })
                    }, 1000)
                  }
                }),
                finalize(() => this.isLoading = false),
                catchError(error => of(this.error = error))
              ).subscribe();
            } else if (users.body && users.body.error === "authError") {
              this.errorMsg = users.body.error
              console.log(users.body.error)
              return throwError(users.body.message)
            }
            else {
              return throwError('Invalid Unknown Error');
            }
          }),
          finalize(() => this.isLoading = false),
          catchError(error => of(
            console.log(error)
            
            // this.errorMsg = error.message ? error.message : 'Invalid Error',
            // this.changeLock()
          ))
        ).subscribe();
    }
    // else {
    //   self.openPopUp({
    //     title: 'Login Failed',
    //     msg: 'Please enter mandatory fields with valid information to proceed further'
    //   })
    // }
  }

  openPopUp(obj) {
    this.modalService.setModalData(obj, 'infoModal', true);
    this.modalService.getModal('infoModal').open()

  }

  changeLock() {
    this.lockClass = 'fa-lock shake';
    this.lockStyle = {
      'color': '#ed1c24'
    }
    setTimeout(() => {
      this.lockClass = 'fa-lock';
      this.lockStyle = {
        'color': '#003f88'
      }
      this.errorMsg = '';
    }, 4000)
  }

}
