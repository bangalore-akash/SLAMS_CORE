import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  fullImagePath:string;
  show: boolean;

  loginUserPostData:any = {
    userid:'',
    password:''
  };

  constructor(private router: Router) {

    this.fullImagePath = '/assets/images/inventory1.png';
    this.show = false;
  }
  showpassword() {
    this.show = !this.show;
  }

  gotoForgotPass(){
    this.router.navigate(['/auth/login/forgetPassword']);
  }

  ngOnInit() {

  }
  
  loginAction(){
    console.log(this.loginUserPostData);
    // if (this.authservice.login(this.loginUserPostData)) {
    //   this.router.navigate(['']);
    // }
  }

}
