import { HttpHeaders, HttpParams } from '@angular/common/http'

export function  getCustomHeaders (headerParams?: [{name: string, value: string}] ): HttpHeaders{
    let headers = new HttpHeaders().set("Content-Type","application/json");
if(headerParams){
for(let [key, paramVal] of Object.entries(headerParams))
 headers.set(key, paramVal.value);

}
return headers;
}