import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment as env } from '@env/environment';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { getCustomHeaders } from './api-utils';
// import { AuthService } from './auth.service';

const BASE_URL = env.serverUrlSet;

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private options = { headers: new HttpHeaders().set('Content-Type', 'application/json') };

  constructor(
    private httpClient: HttpClient, 
    // private auth:AuthService
  ) { }

  public get(path: string, app: string, params): Observable<any> {
    if (path == '/employees/entitlements') {
      return this.httpClient.get(BASE_URL[app] + path, { params }).pipe(catchError(this.formatErrors));
    } else
    return this.httpClient.get( path, { params }).pipe(catchError(this.formatErrors));
  }

  public getImage(app: string, path: string, params): Observable<any> {
    return this.httpClient.get(BASE_URL[app] + path, { params }).pipe(catchError(this.formatErrors));
  }

  public put(path: string, app: string, body: object = {}, additionalHeaderParams?): Observable<any> {
     let options = getCustomHeaders(additionalHeaderParams);
   return this.httpClient
      .put( path, JSON.stringify(body),{headers: options})
      .pipe(catchError(this.formatErrors));
  }

  public post(path: string, app: string, body: object = {}, additionalHeaderParams?): Observable<Response> {
    if (path == '/auth/authenticate') {
      this.options['observe'] = 'response';
    } 
    if (app == 'repayment') {
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        }),
        observe: 'response' as 'body'
      };
      return this.httpClient
        .post(BASE_URL[app], JSON.stringify(body), httpOptions)
        .pipe(catchError(this.formatErrors));
    }
    else {
      return this.httpClient
        .post(path, body,
          additionalHeaderParams!== undefined? {headers: getCustomHeaders(additionalHeaderParams)}:this.options)
        .pipe(catchError(this.formatErrors));
    }
  }

  public delete(path: string): Observable<any> {
    return this.httpClient.delete(BASE_URL + path).pipe(catchError(this.formatErrors));
  }

  public formatErrors(error: any): Observable<any> {
    return throwError(error.error);
  }
}
