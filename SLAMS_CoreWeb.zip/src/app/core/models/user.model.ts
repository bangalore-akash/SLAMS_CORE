export class User {
  username: string;
  password: string;
  token: string;
  data : object;
}
