import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataTrasferService {

  private dataSource = new Subject();
  currentData = this.dataSource.asObservable();
  
  constructor() { }

  changeData(data:any) {
    this.dataSource.next(data)
  }

  private roleData = new Subject();
  currentRole = this.roleData.asObservable();

  getRole(data:any) {
    this.roleData.next(data)
  }

  private colenCollectiondata = new Subject();
  currentColenCollectiondata = this.colenCollectiondata.asObservable();

  getColenCollectiondata(data:any) {
    this.colenCollectiondata.next(data);
  }
}
