import { Routes } from '@angular/router';

export const CONTENT_ROUTES: Routes = [
  {
    path: 'dashboard',
    loadChildren: 'app/modules/dashboard/dashboard.module#DashboardModule'
  },
  {
    path: 'home',
    loadChildren: 'app/modules/home/home.module#HomeModule'
  },
  {
    path: 'about',
    loadChildren: 'app/modules/about/about.module#AboutModule'
  },
  {
    path: 'repay',
    loadChildren: 'app/modules/repayment/repayment.module#RepaymentModule'
  }
];
